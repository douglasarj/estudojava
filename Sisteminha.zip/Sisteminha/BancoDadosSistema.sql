CREATE DATABASE  IF NOT EXISTS `demostracao` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `demostracao`;
-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: localhost    Database: demostracao
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cliente`
--

DROP TABLE IF EXISTS `cliente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cliente` (
  `id_cliente` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(45) DEFAULT NULL,
  `idade` int DEFAULT NULL,
  `cpf` varchar(45) DEFAULT NULL,
  `situacao` varchar(45) NOT NULL,
  PRIMARY KEY (`id_cliente`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cliente`
--

LOCK TABLES `cliente` WRITE;
/*!40000 ALTER TABLE `cliente` DISABLE KEYS */;
INSERT INTO `cliente` VALUES (4,'Andre Marques',34,'53454353534','Bloqueado'),(5,'Marcos Andre',12,'2312312','Ativo'),(6,'Lucas',34,'324234242','Ativo');
/*!40000 ALTER TABLE `cliente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `listagememprestimo`
--

DROP TABLE IF EXISTS `listagememprestimo`;
/*!50001 DROP VIEW IF EXISTS `listagememprestimo`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `listagememprestimo` AS SELECT 
 1 AS `id_locacao`,
 1 AS `data_inicio`,
 1 AS `data_devolucao`,
 1 AS `multa`,
 1 AS `nome`,
 1 AS `nome_livro`,
 1 AS `situacao`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `livro`
--

DROP TABLE IF EXISTS `livro`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `livro` (
  `id_livro` int NOT NULL AUTO_INCREMENT,
  `nome_livro` varchar(45) DEFAULT NULL,
  `autor` varchar(45) DEFAULT NULL,
  `edicao` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id_livro`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `livro`
--

LOCK TABLES `livro` WRITE;
/*!40000 ALTER TABLE `livro` DISABLE KEYS */;
INSERT INTO `livro` VALUES (1,'Aprendendo TI','SENAC','05 Edição'),(2,'Aprendendo MySQL','Faculdade SENAC','07 Edição'),(4,'Dom Casmurro','Machado de Assis','1ª edição'),(5,'1984','George Orwell','1ª edição'),(6,'O Primo Basílio','José de Alencar','2ª edição'),(7,'A Moreninha','Joaquim Manuel de Macedo','7ª edição'),(8,'A Divina Comédia','Dante Alighieri','1ª edição'),(9,'O Grande Gatsby','F. Scott Fitzgerald','1ª edição'),(10,'Os Miseráveis','Victor Hugo','2ª edição'),(11,'Crime e Castigo','Fiódor Dostoiévski','1ª edição'),(12,'O Retrato de Dorian Gray','Oscar Wilde','1ª edição'),(13,'O Cortiço','Aluísio Azevedo','1ª edição'),(14,'A Metamorfose','Franz Kafka','1ª edição'),(15,'O Senhor dos Anéis: A Sociedade do Anel','J.R.R. Tolkien','1ª edição'),(16,'A Caverna','José Saramago','1ª edição'),(17,'O Pequeno Príncipe','Antoine de Saint-Exupéry','2ª edição'),(18,'Moby Dick','Herman Melville','1ª edição'),(19,'Cem Anos de Solidão','Gabriel García Márquez','1ª edição'),(20,'O Processo','Franz Kafka','1ª edição'),(21,'Fahrenheit 451','Ray Bradbury','1ª edição'),(22,'O Hobbit','J.R.R. Tolkien','1ª edição'),(23,'O Sol é para Todos','Harper Lee','2ª edição');
/*!40000 ALTER TABLE `livro` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `locacao`
--

DROP TABLE IF EXISTS `locacao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `locacao` (
  `id_locacao` int NOT NULL AUTO_INCREMENT,
  `data_inicio` datetime DEFAULT CURRENT_TIMESTAMP,
  `data_devolucao` date DEFAULT NULL,
  `multa` decimal(10,2) DEFAULT NULL,
  `situacao` varchar(45) DEFAULT NULL,
  `id_cliente` int DEFAULT NULL,
  `id_livro` int DEFAULT NULL,
  PRIMARY KEY (`id_locacao`),
  KEY `id_cliente` (`id_cliente`),
  KEY `id_livro` (`id_livro`),
  CONSTRAINT `locacao_ibfk_1` FOREIGN KEY (`id_cliente`) REFERENCES `cliente` (`id_cliente`),
  CONSTRAINT `locacao_ibfk_2` FOREIGN KEY (`id_livro`) REFERENCES `livro` (`id_livro`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `locacao`
--

LOCK TABLES `locacao` WRITE;
/*!40000 ALTER TABLE `locacao` DISABLE KEYS */;
INSERT INTO `locacao` VALUES (2,'2024-12-11 08:35:28','2024-12-31',0.00,'Emprestado',4,7),(3,'2024-12-11 08:50:52','2024-12-18',1.00,'Entregue',5,9),(4,'2024-12-11 09:05:58','2024-12-19',0.00,'Emprestado',6,6);
/*!40000 ALTER TABLE `locacao` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `listagememprestimo`
--

/*!50001 DROP VIEW IF EXISTS `listagememprestimo`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `listagememprestimo` AS select `l`.`id_locacao` AS `id_locacao`,`l`.`data_inicio` AS `data_inicio`,`l`.`data_devolucao` AS `data_devolucao`,`l`.`multa` AS `multa`,`c`.`nome` AS `nome`,`lv`.`nome_livro` AS `nome_livro`,`l`.`situacao` AS `situacao` from ((`locacao` `l` join `cliente` `c` on((`c`.`id_cliente` = `l`.`id_cliente`))) join `livro` `lv` on((`lv`.`id_livro` = `l`.`id_livro`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-12-11  9:16:48
